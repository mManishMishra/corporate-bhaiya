from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import User, MentorProfile, StudentProfile

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        if instance.is_mentor:
            MentorProfile.objects.create(user=instance)
        else:
            StudentProfile.objects.create(user=instance)
