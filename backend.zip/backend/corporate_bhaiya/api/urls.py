from django.urls import path
from .views import *


urlpatterns = [
    path('register/mentor/', MentorRegisterAPIView.as_view(), name='mentor-register'),
    path('register/student/', StudentRegisterAPIView.as_view(), name='student-register'),
    path('login/', LoginAPIView.as_view(), name='user-login'),
    path('logout/', LogoutAPIView.as_view(), name='logout'),
    path('mentor/full-profile/', MentorFullProfileView.as_view(), name='mentor-full-profile'),
    path('student/full-profile/', StudentFullProfileView.as_view(), name='student-full-profile'),
    path('slots/create/', MentorSlotCreateAPIView.as_view(), name='mentor-slot-create'),
    path('slots/available/', AvailableSlotListAPIView.as_view(), name='available-slots'),
    path('slots/book/<int:slot_id>/', BookSlotAPIView.as_view(), name='book-slot'),
   


]
