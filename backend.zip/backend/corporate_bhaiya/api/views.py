from django.shortcuts import render

# Create your views here.
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import *
from rest_framework.permissions import IsAuthenticated
from .models import MentorProfile
from .models import StudentProfile
from rest_framework import status, permissions
from django.utils import timezone
from .models import *
from rest_framework.authtoken.models import Token
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken, TokenError



class MentorRegisterAPIView(APIView):
    def post(self, request):
        serializer = MentorRegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            
            return Response({
                "message": "Mentor registered successfully",
                
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "name": user.name,
                    "is_mentor": user.is_mentor
                }
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class StudentRegisterAPIView(APIView):
    def post(self, request):
        serializer = StudentRegisterSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            
            return Response({
                "message": "Student registered successfully",
                
                "user": {
                    "id": user.id,
                    "email": user.email,
                    "name": user.name,
                    "is_mentor": user.is_mentor
                }
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginAPIView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data
            
            if user:
                refresh = RefreshToken.for_user(user)
                return Response({
                    "message": "Login successful",
                    
                    "user": {
                        "id": user.id,
                        "email": user.email,
                        "name": user.name,
                        
                        "is_mentor": user.is_mentor
                    },
                    "refresh": str(refresh),
                    "access": str(refresh.access_token)
                }, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_401_UNAUTHORIZED)

class LogoutAPIView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        try:
            refresh_token = request.data["refresh"]
            token = RefreshToken(refresh_token)
            token.blacklist()

            return Response({"message": "Logout successful"}, status=status.HTTP_205_RESET_CONTENT)
        except KeyError:
            return Response({"error": "Refresh token is required"}, status=status.HTTP_400_BAD_REQUEST)
        except TokenError:
            return Response({"error": "Invalid or expired token"}, status=status.HTTP_400_BAD_REQUEST)


class MentorFullProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user_serializer = UserUpdateSerializer(request.user)
        mentor_profile, _ = MentorProfile.objects.get_or_create(user=request.user)
        profile_serializer = MentorProfileSerializer(request.user.mentorprofile)
        return Response({
            "user": user_serializer.data,
            "profile": profile_serializer.data
        })

    def put(self, request):
        user_serializer = UserUpdateSerializer(request.user, data=request.data.get('user'), partial=True)
        mentor_profile, _ = MentorProfile.objects.get_or_create(user=request.user)
        profile_serializer = MentorProfileSerializer(mentor_profile, data=request.data.get('profile'), partial=True)

        if user_serializer.is_valid() and profile_serializer.is_valid():
            user_serializer.save()
            profile_serializer.save()
            return Response({
                "message": "Profile updated successfully",
                "user": user_serializer.data,
                "profile": profile_serializer.data
            })

        return Response({
            "user_errors": user_serializer.errors,
            "profile_errors": profile_serializer.errors
        }, status=400)



class StudentFullProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user_serializer = UserUpdateSerializer(request.user)
        profile_serializer = StudentProfileSerializer(request.user.studentprofile)
        return Response({
            "user": user_serializer.data,
            "profile": profile_serializer.data
        })

    def put(self, request):
        user_serializer = UserUpdateSerializer(request.user, data=request.data.get('user'), partial=True)
        profile_serializer = StudentProfileSerializer(request.user.studentprofile, data=request.data.get('profile'), partial=True)

        if user_serializer.is_valid() and profile_serializer.is_valid():
            user_serializer.save()
            profile_serializer.save()
            return Response({
                "message": "Profile updated successfully",
                "user": user_serializer.data,
                "profile": profile_serializer.data
            })

        return Response({
            "user_errors": user_serializer.errors,
            "profile_errors": profile_serializer.errors
        }, status=400)



class MentorSlotCreateAPIView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = SlotSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(mentor=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class AvailableSlotListAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        today = timezone.now().date()
        slots = Slot.objects.filter(is_booked=False, date__gte=today)
        serializer = SlotSerializer(slots, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class BookSlotAPIView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, slot_id):
        try:
            slot = Slot.objects.get(id=slot_id, is_booked=False)
        except Slot.DoesNotExist:
            return Response({'error': 'Slot not available or already booked'}, status=status.HTTP_400_BAD_REQUEST)

        booking = Booking.objects.create(student=request.user, slot=slot)
        slot.is_booked = True
        slot.save()

        serializer = BookingSerializer(booking)
        return Response(serializer.data, status=status.HTTP_201_CREATED)
