from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, MentorProfile, StudentProfile,Slot, Booking


class UserAdmin(BaseUserAdmin):
    list_display = ('email', 'name', 'is_mentor', 'is_staff', 'is_superuser')
    list_filter = ('is_mentor', 'is_staff', 'is_superuser')
    search_fields = ('email', 'name')
    ordering = ('email',)
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal Info', {'fields': ('name', 'phone', 'is_mentor')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'name', 'password1', 'password2', 'is_mentor'),
        }),
    )

admin.site.register(User, UserAdmin)

@admin.register(MentorProfile)
class MentorProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'experience', 'skills', 'available_days')
    search_fields = ('user__email', 'skills')
    list_filter = ('experience',)

@admin.register(StudentProfile)
class StudentProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'college')
    search_fields = ('user__email', 'college')



@admin.register(Slot)
class SlotAdmin(admin.ModelAdmin):
    list_display = ('mentor', 'date', 'start_time', 'end_time', 'is_booked')
    list_filter = ('mentor', 'is_booked', 'date')
    search_fields = ('mentor__email',)
    ordering = ('date', 'start_time')


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('slot', 'student', 'booked_at')
    list_filter = ('student', 'slot__mentor', 'booked_at')
    search_fields = ('student__email', 'slot__mentor__email')
    ordering = ('-booked_at',)


